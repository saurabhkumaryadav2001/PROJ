package main

import (
	"context"
	"errors"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"
)

func main() {
	logger := slog.New(slog.NewJSONHandler(os.Stdout, nil))
	cfg, err := LoadConfig()
	if err != nil {
		logger.Error("configuration_error", "error", err)
		os.Exit(1)
	}

	startupCtx, startupCancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer startupCancel()
	db, err := OpenDB(startupCtx, cfg)
	if err != nil {
		logger.Error("database_startup_failed", "error", err)
		os.Exit(1)
	}
	defer db.Close()

	store := NewPostgresStore(db)
	tokens := TokenManager{Secret: cfg.JWTSecret, Issuer: cfg.JWTIssuer, Audience: cfg.JWTAudience, AccessTTL: cfg.AccessTokenTTL}
	auth, err := NewAuthService(store, PasswordHasher{Iterations: cfg.PasswordIterations}, tokens, cfg.RefreshTokenTTL)
	if err != nil {
		logger.Error("auth_service_init_failed", "error", err)
		os.Exit(1)
	}
	if err := auth.BootstrapAdmin(startupCtx, cfg.BootstrapAdminEmail, cfg.BootstrapAdminPass); err != nil {
		logger.Error("bootstrap_admin_failed", "error", err)
		os.Exit(1)
	}

	api := &API{Auth: auth, Tokens: tokens, Store: store}
	server := &http.Server{
		Addr: cfg.Address, Handler: api.Routes(),
		ReadHeaderTimeout: 5 * time.Second, ReadTimeout: 10 * time.Second,
		WriteTimeout: 15 * time.Second, IdleTimeout: 60 * time.Second,
	}

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	serverErr := make(chan error, 1)
	go func() {
		logger.Info("http_server_starting", "address", cfg.Address)
		if err := server.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			serverErr <- err
		}
		close(serverErr)
	}()

	select {
	case <-ctx.Done():
		shutdownCtx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		defer cancel()
		if err := server.Shutdown(shutdownCtx); err != nil {
			logger.Error("http_shutdown_failed", "error", err)
		}
	case err := <-serverErr:
		if err != nil {
			logger.Error("http_server_failed", "error", err)
			os.Exit(1)
		}
	}
	logger.Info("http_server_stopped")
}

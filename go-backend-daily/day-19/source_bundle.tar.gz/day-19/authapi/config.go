package main

import (
	"errors"
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"
)

type Config struct {
	Address             string
	DatabaseURL         string
	JWTSecret           []byte
	JWTIssuer           string
	JWTAudience         string
	AccessTokenTTL      time.Duration
	RefreshTokenTTL     time.Duration
	PasswordIterations  int
	MaxOpenConns        int
	MaxIdleConns        int
	ConnMaxLifetime     time.Duration
	BootstrapAdminEmail string
	BootstrapAdminPass  string
}

func LoadConfig() (Config, error) {
	get := func(key, fallback string) string {
		if value := strings.TrimSpace(os.Getenv(key)); value != "" {
			return value
		}
		return fallback
	}

	appEnv := get("APP_ENV", "development")
	if appEnv != "development" && appEnv != "test" && appEnv != "staging" && appEnv != "production" {
		return Config{}, errors.New("APP_ENV must be development, test, staging or production")
	}

	databaseURL := get("DATABASE_URL", "")
	if databaseURL == "" {
		return Config{}, errors.New("DATABASE_URL is required")
	}

	secret := os.Getenv("JWT_SECRET")
	if secret == "" {
		if appEnv == "production" {
			return Config{}, errors.New("JWT_SECRET is required in production")
		}
		secret = "local-development-only-secret-change-before-deploy-2026"
	}
	if len([]byte(secret)) < 32 {
		return Config{}, errors.New("JWT_SECRET must contain at least 32 bytes")
	}

	iterations, err := strconv.Atoi(get("PASSWORD_ITERATIONS", "600000"))
	if err != nil || iterations < 600000 || iterations > 2000000 {
		return Config{}, errors.New("PASSWORD_ITERATIONS must be between 600000 and 2000000")
	}
	accessTTL, err := time.ParseDuration(get("ACCESS_TOKEN_TTL", "15m"))
	if err != nil || accessTTL < time.Minute || accessTTL > time.Hour {
		return Config{}, errors.New("ACCESS_TOKEN_TTL must be between 1m and 1h")
	}
	refreshTTL, err := time.ParseDuration(get("REFRESH_TOKEN_TTL", "168h"))
	if err != nil || refreshTTL < time.Hour || refreshTTL > 30*24*time.Hour {
		return Config{}, errors.New("REFRESH_TOKEN_TTL must be between 1h and 720h")
	}
	maxOpen, err := strconv.Atoi(get("DB_MAX_OPEN_CONNS", "20"))
	if err != nil || maxOpen < 1 || maxOpen > 200 {
		return Config{}, errors.New("DB_MAX_OPEN_CONNS must be between 1 and 200")
	}
	maxIdle, err := strconv.Atoi(get("DB_MAX_IDLE_CONNS", "5"))
	if err != nil || maxIdle < 0 || maxIdle > maxOpen {
		return Config{}, errors.New("DB_MAX_IDLE_CONNS must be between 0 and DB_MAX_OPEN_CONNS")
	}
	lifetime, err := time.ParseDuration(get("DB_CONN_MAX_LIFETIME", "30m"))
	if err != nil || lifetime <= 0 || lifetime > 24*time.Hour {
		return Config{}, errors.New("DB_CONN_MAX_LIFETIME must be between 1ns and 24h")
	}

	return Config{
		Address: get("HTTP_ADDR", ":8080"), DatabaseURL: databaseURL,
		JWTSecret: []byte(secret), JWTIssuer: get("JWT_ISSUER", "go-backend-daily"),
		JWTAudience:    get("JWT_AUDIENCE", "go-backend-api"),
		AccessTokenTTL: accessTTL, RefreshTokenTTL: refreshTTL,
		PasswordIterations: iterations, MaxOpenConns: maxOpen, MaxIdleConns: maxIdle,
		ConnMaxLifetime:     lifetime,
		BootstrapAdminEmail: strings.ToLower(get("BOOTSTRAP_ADMIN_EMAIL", "")),
		BootstrapAdminPass:  os.Getenv("BOOTSTRAP_ADMIN_PASSWORD"),
	}, nil
}

func (c Config) Validate() error {
	if c.Address == "" || c.DatabaseURL == "" || len(c.JWTSecret) < 32 {
		return fmt.Errorf("address, database URL and a 32-byte JWT secret are required")
	}
	return nil
}

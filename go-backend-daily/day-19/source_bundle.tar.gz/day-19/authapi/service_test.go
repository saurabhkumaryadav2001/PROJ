package main

import (
	"context"
	"errors"
	"fmt"
	"strings"
	"sync"
	"testing"
	"time"
)

type fakeStore struct {
	mu       sync.Mutex
	users    map[string]User
	byID     map[string]User
	sessions map[string]RefreshSession
	used     map[string]RefreshSession
}

func newFakeStore() *fakeStore {
	return &fakeStore{users: map[string]User{}, byID: map[string]User{}, sessions: map[string]RefreshSession{}, used: map[string]RefreshSession{}}
}
func (s *fakeStore) Ping(context.Context) error { return nil }
func (s *fakeStore) CreateUser(_ context.Context, u User) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if _, ok := s.users[u.Email]; ok {
		return ErrEmailExists
	}
	s.users[u.Email] = u
	s.byID[u.ID] = u
	return nil
}
func (s *fakeStore) UserByEmail(_ context.Context, email string) (User, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	u, ok := s.users[email]
	if !ok {
		return User{}, ErrNotFound
	}
	return u, nil
}
func (s *fakeStore) UserByID(_ context.Context, id string) (User, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	u, ok := s.byID[id]
	if !ok {
		return User{}, ErrNotFound
	}
	return u, nil
}
func (s *fakeStore) CreateRefresh(_ context.Context, rs RefreshSession) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.sessions[rs.TokenHash] = rs
	return nil
}
func (s *fakeStore) RotateRefresh(_ context.Context, oldHash string, replacement RefreshSession, now time.Time) (User, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	old, ok := s.sessions[oldHash]
	if !ok {
		return User{}, ErrRefreshInvalid
	}
	if !old.ExpiresAt.After(now) {
		delete(s.sessions, oldHash)
		return User{}, ErrRefreshInvalid
	}
	if old.FamilyID == "" {
		return User{}, ErrRefreshInvalid
	}
	for hash, session := range s.sessions {
		if session.FamilyID == old.FamilyID && session.ID == old.ID {
			// The map stores only active tokens; deleting the old token simulates consumption.
			s.used[hash] = session
			delete(s.sessions, hash)
			break
		}
	}
	user, ok := s.byID[old.UserID]
	if !ok {
		return User{}, ErrRefreshInvalid
	}
	replacement.FamilyID = old.FamilyID
	replacement.UserID = old.UserID
	s.sessions[replacement.TokenHash] = replacement
	return user, nil
}
func (s *fakeStore) RevokeRefresh(_ context.Context, tokenHash string, _ time.Time) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	old, ok := s.sessions[tokenHash]
	if !ok {
		return ErrRefreshInvalid
	}
	for hash, session := range s.sessions {
		if session.FamilyID == old.FamilyID {
			delete(s.sessions, hash)
		}
	}
	return nil
}

func testService(t *testing.T) (*AuthService, *fakeStore, TokenManager) {
	t.Helper()
	store := newFakeStore()
	tokens := TokenManager{Secret: []byte("0123456789abcdef0123456789abcdef"), Issuer: "test-issuer", Audience: "test-api", AccessTTL: 15 * time.Minute}
	auth, err := NewAuthService(store, PasswordHasher{Iterations: 1000}, tokens, 24*time.Hour)
	if err != nil {
		t.Fatal(err)
	}
	return auth, store, tokens
}

func TestRegisterLoginAndRefresh(t *testing.T) {
	ctx := context.Background()
	auth, _, tokens := testService(t)
	user, err := auth.Register(ctx, "User@Example.com", "long-password-123")
	if err != nil {
		t.Fatal(err)
	}
	if user.Email != "user@example.com" || user.Role != RoleUser {
		t.Fatalf("unexpected user: %+v", user)
	}
	if _, err := auth.Register(ctx, "user@example.com", "long-password-123"); !errors.Is(err, ErrEmailExists) {
		t.Fatalf("duplicate registration error = %v", err)
	}
	pair, err := auth.Login(ctx, "USER@example.com", "long-password-123")
	if err != nil {
		t.Fatal(err)
	}
	if _, err := tokens.Verify(pair.AccessToken); err != nil {
		t.Fatalf("access token invalid: %v", err)
	}
	rotated, err := auth.Refresh(ctx, pair.RefreshToken)
	if err != nil {
		t.Fatal(err)
	}
	if pair.RefreshToken == rotated.RefreshToken {
		t.Fatal("refresh token was not rotated")
	}
}

func TestInvalidPasswordAndLogout(t *testing.T) {
	ctx := context.Background()
	auth, _, _ := testService(t)
	if _, err := auth.Login(ctx, "missing@example.com", "wrong-password"); !errors.Is(err, ErrInvalidCredentials) {
		t.Fatalf("login error = %v", err)
	}
	_, err := auth.Register(ctx, "logout@example.com", "long-password-123")
	if err != nil {
		t.Fatal(err)
	}
	pair, err := auth.Login(ctx, "logout@example.com", "long-password-123")
	if err != nil {
		t.Fatal(err)
	}
	if err := auth.Logout(ctx, pair.RefreshToken); err != nil {
		t.Fatal(err)
	}
	if _, err := auth.Refresh(ctx, pair.RefreshToken); !errors.Is(err, ErrRefreshInvalid) {
		t.Fatalf("refresh after logout = %v", err)
	}
}

func TestTokenRejectsTampering(t *testing.T) {
	_, _, tokens := testService(t)
	token, _, err := tokens.Issue(User{ID: "user-1", Role: RoleUser})
	if err != nil {
		t.Fatal(err)
	}
	parts := strings.Split(token, ".")
	first := parts[2][0]
	replacement := byte('A')
	if first == replacement {
		replacement = 'B'
	}
	parts[2] = string(replacement) + parts[2][1:]
	changed := strings.Join(parts, ".")
	if _, err := tokens.Verify(changed); err == nil {
		t.Fatal("tampered token accepted")
	}
}

func TestConcurrentRefreshOneRotationWins(t *testing.T) {
	ctx := context.Background()
	auth, _, _ := testService(t)
	if _, err := auth.Register(ctx, "race@example.com", "long-password-123"); err != nil {
		t.Fatal(err)
	}
	pair, err := auth.Login(ctx, "race@example.com", "long-password-123")
	if err != nil {
		t.Fatal(err)
	}
	var wg sync.WaitGroup
	wg.Add(2)
	results := make(chan error, 2)
	for i := 0; i < 2; i++ {
		go func() { defer wg.Done(); _, err := auth.Refresh(ctx, pair.RefreshToken); results <- err }()
	}
	wg.Wait()
	close(results)
	successes := 0
	for err := range results {
		if err == nil {
			successes++
		}
	}
	if successes != 1 {
		t.Fatalf("successful rotations = %d, want exactly 1", successes)
	}
}

func TestPBKDF2SHA256KnownVector(t *testing.T) {
	got := fmt.Sprintf("%x", pbkdf2SHA256([]byte("password"), []byte("salt"), 1, 32))
	want := "120fb6cffcf8b32c43e7225256c4f837a86548c92ccc35480805987cb70be17b"
	if got != want {
		t.Fatalf("PBKDF2 vector = %s, want %s", got, want)
	}
}

type sqlStateError struct{ state string }

func (e sqlStateError) Error() string    { return "database error" }
func (e sqlStateError) SQLState() string { return e.state }

func TestUniqueViolationDetection(t *testing.T) {
	if !isUniqueViolation(sqlStateError{state: "23505"}) {
		t.Fatal("23505 should be a unique violation")
	}
	if isUniqueViolation(sqlStateError{state: "08006"}) {
		t.Fatal("connection error must not be treated as unique violation")
	}
}

func FuzzTokenVerifyRejectsMalformedInput(f *testing.F) {
	f.Add("")
	f.Add("not.a.jwt")
	f.Add("eyJhbGciOiJub25lIn0.e30.")
	f.Fuzz(func(t *testing.T, token string) {
		manager := TokenManager{Secret: []byte("0123456789abcdef0123456789abcdef"), Issuer: "issuer", Audience: "audience", AccessTTL: time.Minute}
		_, _ = manager.Verify(token)
	})
}

func BenchmarkPasswordVerify(b *testing.B) {
	hasher := PasswordHasher{Iterations: 1000}
	encoded, err := hasher.Hash("benchmark-password-123")
	if err != nil {
		b.Fatal(err)
	}
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		if !hasher.Verify("benchmark-password-123", encoded) {
			b.Fatal("verification failed")
		}
	}
}

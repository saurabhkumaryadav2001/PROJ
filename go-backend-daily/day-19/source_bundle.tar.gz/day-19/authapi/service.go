package main

import (
	"context"
	"errors"
	"fmt"
	"net/mail"
	"strings"
	"time"
)

type AuthService struct {
	store      Store
	hasher     PasswordHasher
	tokens     TokenManager
	refreshTTL time.Duration
	dummyHash  string
}

func NewAuthService(store Store, hasher PasswordHasher, tokens TokenManager, refreshTTL time.Duration) (*AuthService, error) {
	dummy, err := hasher.Hash("dummy-password-never-used")
	if err != nil {
		return nil, fmt.Errorf("prepare dummy password hash: %w", err)
	}
	return &AuthService{store: store, hasher: hasher, tokens: tokens, refreshTTL: refreshTTL, dummyHash: dummy}, nil
}

func normalizeEmail(email string) (string, error) {
	email = strings.ToLower(strings.TrimSpace(email))
	parsed, err := mail.ParseAddress(email)
	if err != nil || parsed.Address != email || len(email) > 254 {
		return "", ErrInvalidInput
	}
	return email, nil
}

func (s *AuthService) Register(ctx context.Context, email, password string) (User, error) {
	email, err := normalizeEmail(email)
	if err != nil {
		return User{}, err
	}
	if len(password) < 12 || len(password) > 128 {
		return User{}, fmt.Errorf("%w: password must be 12-128 bytes", ErrInvalidInput)
	}
	hash, err := s.hasher.Hash(password)
	if err != nil {
		return User{}, fmt.Errorf("hash password: %w", err)
	}
	id, err := randomUUID()
	if err != nil {
		return User{}, err
	}
	user := User{ID: id, Email: email, PasswordHash: hash, Role: RoleUser}
	if err := s.store.CreateUser(ctx, user); err != nil {
		return User{}, err
	}
	return user, nil
}

func (s *AuthService) BootstrapAdmin(ctx context.Context, email, password string) error {
	if strings.TrimSpace(email) == "" && password == "" {
		return nil
	}
	if strings.TrimSpace(email) == "" || password == "" {
		return errors.New("both bootstrap admin email and password are required")
	}
	email, err := normalizeEmail(email)
	if err != nil {
		return err
	}
	if len(password) < 12 || len(password) > 128 {
		return errors.New("bootstrap admin password must be 12-128 bytes")
	}
	if _, err := s.store.UserByEmail(ctx, email); err == nil {
		return nil
	} else if !errors.Is(err, ErrNotFound) {
		return err
	}
	hash, err := s.hasher.Hash(password)
	if err != nil {
		return err
	}
	id, err := randomUUID()
	if err != nil {
		return err
	}
	return s.store.CreateUser(ctx, User{ID: id, Email: email, PasswordHash: hash, Role: RoleAdmin})
}

func (s *AuthService) Login(ctx context.Context, email, password string) (TokenPair, error) {
	if len(password) == 0 || len(password) > 128 {
		return TokenPair{}, ErrInvalidCredentials
	}
	normalized, err := normalizeEmail(email)
	if err != nil {
		normalized = "invalid@example.invalid"
	}
	user, findErr := s.store.UserByEmail(ctx, normalized)
	storedHash := s.dummyHash
	if findErr == nil {
		storedHash = user.PasswordHash
	} else if !errors.Is(findErr, ErrNotFound) {
		return TokenPair{}, fmt.Errorf("lookup login user: %w", findErr)
	}
	valid := s.hasher.Verify(password, storedHash)
	if findErr != nil || !valid {
		return TokenPair{}, ErrInvalidCredentials
	}
	return s.issuePair(ctx, user)
}

func (s *AuthService) issuePair(ctx context.Context, user User) (TokenPair, error) {
	access, claims, err := s.tokens.Issue(user)
	if err != nil {
		return TokenPair{}, err
	}
	refresh, err := randomToken(32)
	if err != nil {
		return TokenPair{}, err
	}
	sessionID, err := randomUUID()
	if err != nil {
		return TokenPair{}, err
	}
	familyID, err := randomUUID()
	if err != nil {
		return TokenPair{}, err
	}
	expires := time.Now().UTC().Add(s.refreshTTL)
	session := RefreshSession{ID: sessionID, FamilyID: familyID, UserID: user.ID, TokenHash: hashOpaqueToken(refresh), ExpiresAt: expires}
	if err := s.store.CreateRefresh(ctx, session); err != nil {
		return TokenPair{}, fmt.Errorf("persist refresh session: %w", err)
	}
	return TokenPair{AccessToken: access, TokenType: "Bearer", ExpiresAt: time.Unix(claims.ExpiresAt, 0).UTC(), RefreshToken: refresh}, nil
}

func (s *AuthService) Refresh(ctx context.Context, oldToken string) (TokenPair, error) {
	if len(oldToken) < 32 || len(oldToken) > 256 {
		return TokenPair{}, ErrRefreshInvalid
	}
	newToken, err := randomToken(32)
	if err != nil {
		return TokenPair{}, err
	}
	newID, err := randomUUID()
	if err != nil {
		return TokenPair{}, err
	}
	now := time.Now().UTC()
	user, err := s.store.RotateRefresh(ctx, hashOpaqueToken(oldToken), RefreshSession{
		ID: newID, TokenHash: hashOpaqueToken(newToken), ExpiresAt: now.Add(s.refreshTTL),
	}, now)
	if err != nil {
		return TokenPair{}, err
	}
	access, claims, err := s.tokens.Issue(user)
	if err != nil {
		return TokenPair{}, fmt.Errorf("issue access token after refresh rotation: %w", err)
	}
	return TokenPair{AccessToken: access, TokenType: "Bearer", ExpiresAt: time.Unix(claims.ExpiresAt, 0).UTC(), RefreshToken: newToken}, nil
}

func (s *AuthService) Logout(ctx context.Context, refreshToken string) error {
	if len(refreshToken) < 32 || len(refreshToken) > 256 {
		return ErrRefreshInvalid
	}
	return s.store.RevokeRefresh(ctx, hashOpaqueToken(refreshToken), time.Now().UTC())
}

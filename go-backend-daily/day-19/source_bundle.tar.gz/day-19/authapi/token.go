package main

import (
	"bytes"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"strings"
	"time"
)

const jwtHeader = `{"alg":"HS256","typ":"JWT"}`
const maxJWTLength = 8192

type TokenManager struct {
	Secret    []byte
	Issuer    string
	Audience  string
	AccessTTL time.Duration
	Now       func() time.Time
}

func (m TokenManager) now() time.Time {
	if m.Now != nil {
		return m.Now().UTC()
	}
	return time.Now().UTC()
}

func (m TokenManager) Issue(user User) (string, Claims, error) {
	if len(m.Secret) < 32 || m.Issuer == "" || m.Audience == "" || m.AccessTTL <= 0 {
		return "", Claims{}, errors.New("token manager is not configured")
	}
	now := m.now()
	jti, err := randomToken(16)
	if err != nil {
		return "", Claims{}, err
	}
	claims := Claims{
		Issuer: m.Issuer, Subject: user.ID, Audience: m.Audience,
		IssuedAt: now.Unix(), NotBefore: now.Unix(), ExpiresAt: now.Add(m.AccessTTL).Unix(),
		JWTID: jti, Role: user.Role,
	}
	payload, err := json.Marshal(claims)
	if err != nil {
		return "", Claims{}, err
	}
	unsigned := base64.RawURLEncoding.EncodeToString([]byte(jwtHeader)) + "." + base64.RawURLEncoding.EncodeToString(payload)
	mac := hmac.New(sha256.New, m.Secret)
	_, _ = mac.Write([]byte(unsigned))
	return unsigned + "." + base64.RawURLEncoding.EncodeToString(mac.Sum(nil)), claims, nil
}

func (m TokenManager) Verify(token string) (Claims, error) {
	var claims Claims
	if len(token) == 0 || len(token) > maxJWTLength {
		return claims, errors.New("invalid token")
	}
	parts := strings.Split(token, ".")
	if len(parts) != 3 {
		return claims, errors.New("invalid token structure")
	}
	header, err := base64.RawURLEncoding.DecodeString(parts[0])
	if err != nil || string(header) != jwtHeader {
		return claims, errors.New("unsupported token header")
	}
	signature, err := base64.RawURLEncoding.DecodeString(parts[2])
	if err != nil {
		return claims, errors.New("invalid signature encoding")
	}
	mac := hmac.New(sha256.New, m.Secret)
	_, _ = mac.Write([]byte(parts[0] + "." + parts[1]))
	if !hmac.Equal(signature, mac.Sum(nil)) {
		return claims, errors.New("invalid signature")
	}
	payload, err := base64.RawURLEncoding.DecodeString(parts[1])
	if err != nil {
		return claims, errors.New("invalid payload encoding")
	}
	decoder := json.NewDecoder(bytes.NewReader(payload))
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(&claims); err != nil {
		return Claims{}, err
	}
	var extra any
	if err := decoder.Decode(&extra); err != io.EOF {
		return Claims{}, errors.New("trailing token payload")
	}
	now := m.now().Unix()
	if claims.Issuer != m.Issuer || claims.Audience != m.Audience || claims.Subject == "" || claims.JWTID == "" {
		return Claims{}, errors.New("invalid token claims")
	}
	if claims.IssuedAt <= 0 || claims.ExpiresAt <= claims.IssuedAt || claims.ExpiresAt <= now || claims.NotBefore > now || claims.IssuedAt > now+30 {
		return Claims{}, errors.New("token expired or not yet valid")
	}
	if claims.Role != RoleUser && claims.Role != RoleAdmin {
		return Claims{}, errors.New("invalid token role")
	}
	return claims, nil
}

func randomToken(size int) (string, error) {
	buffer := make([]byte, size)
	if _, err := rand.Read(buffer); err != nil {
		return "", fmt.Errorf("generate random token: %w", err)
	}
	return base64.RawURLEncoding.EncodeToString(buffer), nil
}

func hashOpaqueToken(token string) string {
	sum := sha256.Sum256([]byte(token))
	return base64.RawURLEncoding.EncodeToString(sum[:])
}

func randomUUID() (string, error) {
	buffer := make([]byte, 16)
	if _, err := rand.Read(buffer); err != nil {
		return "", fmt.Errorf("generate UUID: %w", err)
	}
	buffer[6] = (buffer[6] & 0x0f) | 0x40
	buffer[8] = (buffer[8] & 0x3f) | 0x80
	return fmt.Sprintf("%x-%x-%x-%x-%x", buffer[0:4], buffer[4:6], buffer[6:8], buffer[8:10], buffer[10:16]), nil
}

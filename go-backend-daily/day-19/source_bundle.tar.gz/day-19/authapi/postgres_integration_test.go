//go:build integration && pgx

package main

import (
	"context"
	"database/sql"
	"fmt"
	"os"
	"testing"
	"time"
)

func TestPostgresStorePersistentRegistrationAndRefreshReplay(t *testing.T) {
	dsn := os.Getenv("TEST_DATABASE_URL")
	if dsn == "" {
		t.Skip("set TEST_DATABASE_URL to run PostgreSQL integration test")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
	defer cancel()
	db, err := sql.Open("pgx", dsn)
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	db.SetMaxOpenConns(1)
	if err := db.PingContext(ctx); err != nil {
		t.Fatal(err)
	}
	schema := fmt.Sprintf("day19_test_%d", time.Now().UnixNano())
	if _, err := db.ExecContext(ctx, `CREATE SCHEMA `+schema); err != nil {
		t.Fatal(err)
	}
	defer func() { _, _ = db.ExecContext(context.Background(), `DROP SCHEMA `+schema+` CASCADE`) }()
	if _, err := db.ExecContext(ctx, `SET search_path TO `+schema); err != nil {
		t.Fatal(err)
	}
	for _, ddl := range []string{
		`CREATE TABLE app_users (id UUID PRIMARY KEY, email VARCHAR(254) NOT NULL UNIQUE, password_hash VARCHAR(255) NOT NULL, role VARCHAR(20) NOT NULL CHECK (role IN ('user','admin')), disabled_at TIMESTAMPTZ NULL)`,
		`CREATE TABLE refresh_sessions (id UUID PRIMARY KEY, family_id UUID NOT NULL, token_hash CHAR(43) NOT NULL UNIQUE, user_id UUID NOT NULL REFERENCES app_users(id) ON DELETE CASCADE, expires_at TIMESTAMPTZ NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), consumed_at TIMESTAMPTZ NULL, revoked_at TIMESTAMPTZ NULL, replaced_by_id UUID NULL REFERENCES refresh_sessions(id))`,
	} {
		if _, err := db.ExecContext(ctx, ddl); err != nil {
			t.Fatal(err)
		}
	}
	store := NewPostgresStore(db)
	user := User{ID: "7f7b9b7c-0c2e-4e83-a1de-8c8f4c22d901", Email: "pg@example.com", PasswordHash: "test-hash", Role: RoleUser}
	if err := store.CreateUser(ctx, user); err != nil {
		t.Fatal(err)
	}
	if err := store.CreateUser(ctx, user); err != ErrEmailExists {
		t.Fatalf("duplicate user error = %v", err)
	}
	first := RefreshSession{ID: "11111111-1111-4111-8111-111111111111", FamilyID: "22222222-2222-4222-8222-222222222222", UserID: user.ID, TokenHash: hashOpaqueToken("first-refresh-token-value-long-enough"), ExpiresAt: time.Now().Add(time.Hour)}
	if err := store.CreateRefresh(ctx, first); err != nil {
		t.Fatal(err)
	}
	replacement := RefreshSession{ID: "33333333-3333-4333-8333-333333333333", TokenHash: hashOpaqueToken("replacement-refresh-token-value-long"), ExpiresAt: time.Now().Add(time.Hour)}
	got, err := store.RotateRefresh(ctx, first.TokenHash, replacement, time.Now())
	if err != nil || got.ID != user.ID {
		t.Fatalf("rotation user=%+v err=%v", got, err)
	}
	_, err = store.RotateRefresh(ctx, first.TokenHash, RefreshSession{ID: "44444444-4444-4444-8444-444444444444", TokenHash: hashOpaqueToken("another-replacement-token-value-long"), ExpiresAt: time.Now().Add(time.Hour)}, time.Now())
	if err != ErrRefreshReuse {
		t.Fatalf("replay error = %v, want ErrRefreshReuse", err)
	}
	if err := store.RevokeRefresh(ctx, replacement.TokenHash, time.Now()); err == nil {
		t.Fatal("family should already be revoked after replay")
	}
}

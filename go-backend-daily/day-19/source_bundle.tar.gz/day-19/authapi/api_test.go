package main

import (
	"bytes"
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"
)

func TestHTTPRegisterLoginMeAndRBAC(t *testing.T) {
	ctx := context.Background()
	store := newFakeStore()
	tokens := TokenManager{Secret: []byte("0123456789abcdef0123456789abcdef"), Issuer: "test-issuer", Audience: "test-api", AccessTTL: 15 * time.Minute}
	auth, err := NewAuthService(store, PasswordHasher{Iterations: 1000}, tokens, 24*time.Hour)
	if err != nil {
		t.Fatal(err)
	}
	api := (&API{Auth: auth, Tokens: tokens, Store: store}).Routes()

	registerBody := `{"email":"web@example.com","password":"long-password-123"}`
	register := httptest.NewRequest(http.MethodPost, "/auth/register", strings.NewReader(registerBody))
	register.Header.Set("Content-Type", "application/json")
	registerResponse := httptest.NewRecorder()
	api.ServeHTTP(registerResponse, register)
	if registerResponse.Code != http.StatusCreated {
		t.Fatalf("register status=%d body=%s", registerResponse.Code, registerResponse.Body.String())
	}

	login := httptest.NewRequest(http.MethodPost, "/auth/login", strings.NewReader(registerBody))
	login.Header.Set("Content-Type", "application/json")
	loginResponse := httptest.NewRecorder()
	api.ServeHTTP(loginResponse, login)
	if loginResponse.Code != http.StatusOK {
		t.Fatalf("login status=%d body=%s", loginResponse.Code, loginResponse.Body.String())
	}
	var pair TokenPair
	if err := json.Unmarshal(loginResponse.Body.Bytes(), &pair); err != nil {
		t.Fatal(err)
	}

	me := httptest.NewRequest(http.MethodGet, "/api/me", nil)
	me.Header.Set("Authorization", "Bearer "+pair.AccessToken)
	meResponse := httptest.NewRecorder()
	api.ServeHTTP(meResponse, me)
	if meResponse.Code != http.StatusOK {
		t.Fatalf("me status=%d body=%s", meResponse.Code, meResponse.Body.String())
	}

	admin := httptest.NewRequest(http.MethodGet, "/api/admin/users", nil)
	admin.Header.Set("Authorization", "Bearer "+pair.AccessToken)
	adminResponse := httptest.NewRecorder()
	api.ServeHTTP(adminResponse, admin)
	if adminResponse.Code != http.StatusForbidden {
		t.Fatalf("user admin status=%d, want 403", adminResponse.Code)
	}

	if err := auth.BootstrapAdmin(ctx, "admin@example.com", "a-long-admin-password-123"); err != nil {
		t.Fatal(err)
	}
	adminLoginBody := `{"email":"admin@example.com","password":"a-long-admin-password-123"}`
	adminLogin := httptest.NewRequest(http.MethodPost, "/auth/login", strings.NewReader(adminLoginBody))
	adminLoginResponse := httptest.NewRecorder()
	api.ServeHTTP(adminLoginResponse, adminLogin)
	if adminLoginResponse.Code != http.StatusOK {
		t.Fatalf("admin login status=%d", adminLoginResponse.Code)
	}
	var adminPair TokenPair
	if err := json.Unmarshal(adminLoginResponse.Body.Bytes(), &adminPair); err != nil {
		t.Fatal(err)
	}
	admin.Header.Set("Authorization", "Bearer "+adminPair.AccessToken)
	adminResponse = httptest.NewRecorder()
	api.ServeHTTP(adminResponse, admin)
	if adminResponse.Code != http.StatusOK {
		t.Fatalf("admin endpoint status=%d body=%s", adminResponse.Code, adminResponse.Body.String())
	}

	unknownField := httptest.NewRequest(http.MethodPost, "/auth/register", bytes.NewBufferString(`{"email":"evil@example.com","password":"long-password-123","role":"admin"}`))
	unknownFieldResponse := httptest.NewRecorder()
	api.ServeHTTP(unknownFieldResponse, unknownField)
	if unknownFieldResponse.Code != http.StatusBadRequest {
		t.Fatalf("unknown role field status=%d, want 400", unknownFieldResponse.Code)
	}
}

func TestProtectedEndpointRequiresBearerToken(t *testing.T) {
	_, store, tokens := testService(t)
	api := (&API{Auth: nil, Tokens: tokens, Store: store}).Routes()
	req := httptest.NewRequest(http.MethodGet, "/api/me", nil)
	response := httptest.NewRecorder()
	api.ServeHTTP(response, req)
	if response.Code != http.StatusUnauthorized {
		t.Fatalf("status=%d, want 401", response.Code)
	}
}

package main

import (
	"context"
	"errors"
	"time"
)

var (
	ErrNotFound           = errors.New("record not found")
	ErrEmailExists        = errors.New("email already registered")
	ErrInvalidCredentials = errors.New("invalid email or password")
	ErrInvalidInput       = errors.New("invalid input")
	ErrRefreshInvalid     = errors.New("refresh token invalid or expired")
	ErrRefreshReuse       = errors.New("refresh token reuse detected; session family revoked")
)

// Store is the persistence boundary. Services depend on this interface, not SQL.
type Store interface {
	Ping(context.Context) error
	CreateUser(context.Context, User) error
	UserByEmail(context.Context, string) (User, error)
	UserByID(context.Context, string) (User, error)
	CreateRefresh(context.Context, RefreshSession) error
	RotateRefresh(context.Context, string, RefreshSession, time.Time) (User, error)
	RevokeRefresh(context.Context, string, time.Time) error
}

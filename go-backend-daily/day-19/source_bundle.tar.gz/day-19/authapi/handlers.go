package main

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"strings"
)

type principalKey struct{}
type Principal struct {
	UserID string
	Role   Role
}

func PrincipalFromContext(ctx context.Context) (Principal, bool) {
	principal, ok := ctx.Value(principalKey{}).(Principal)
	return principal, ok
}

func AuthMiddleware(tokens TokenManager, next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		parts := strings.Fields(r.Header.Get("Authorization"))
		if len(parts) != 2 || !strings.EqualFold(parts[0], "Bearer") {
			writeError(w, http.StatusUnauthorized, "unauthorized", "valid bearer token required")
			return
		}
		claims, err := tokens.Verify(parts[1])
		if err != nil {
			writeError(w, http.StatusUnauthorized, "unauthorized", "valid bearer token required")
			return
		}
		ctx := context.WithValue(r.Context(), principalKey{}, Principal{UserID: claims.Subject, Role: claims.Role})
		next.ServeHTTP(w, r.WithContext(ctx))
	})
}

func RequireRole(role Role, next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		principal, ok := PrincipalFromContext(r.Context())
		if !ok {
			writeError(w, http.StatusUnauthorized, "unauthorized", "authentication required")
			return
		}
		if principal.Role != role {
			writeError(w, http.StatusForbidden, "forbidden", "insufficient permissions")
			return
		}
		next.ServeHTTP(w, r)
	})
}

type API struct {
	Auth   *AuthService
	Tokens TokenManager
	Store  Store
}
type credentialsRequest struct {
	Email    string `json:"email"`
	Password string `json:"password"`
}
type refreshRequest struct {
	RefreshToken string `json:"refresh_token"`
}
type errorResponse struct {
	Error   string `json:"error"`
	Message string `json:"message"`
}

func (a *API) Routes() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("GET /healthz", a.health)
	mux.HandleFunc("GET /readyz", a.ready)
	mux.HandleFunc("POST /auth/register", a.register)
	mux.HandleFunc("POST /auth/login", a.login)
	mux.HandleFunc("POST /auth/refresh", a.refresh)
	mux.HandleFunc("POST /auth/logout", a.logout)
	mux.Handle("GET /api/me", AuthMiddleware(a.Tokens, http.HandlerFunc(a.me)))
	mux.Handle("GET /api/admin/users", AuthMiddleware(a.Tokens, RequireRole(RoleAdmin, http.HandlerFunc(a.adminUsers))))
	return mux
}

func (a *API) health(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, http.StatusOK, map[string]string{"status": "ok"})
}
func (a *API) ready(w http.ResponseWriter, r *http.Request) {
	if err := a.Store.Ping(r.Context()); err != nil {
		writeError(w, http.StatusServiceUnavailable, "not_ready", "database unavailable")
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"status": "ready"})
}

func (a *API) register(w http.ResponseWriter, r *http.Request) {
	var request credentialsRequest
	if err := decodeJSON(w, r, &request); err != nil {
		writeError(w, http.StatusBadRequest, "invalid_request", "provide one valid JSON email and password")
		return
	}
	user, err := a.Auth.Register(r.Context(), request.Email, request.Password)
	if errors.Is(err, ErrEmailExists) {
		writeError(w, http.StatusConflict, "email_exists", "an account with this email already exists")
		return
	}
	if errors.Is(err, ErrInvalidInput) {
		writeError(w, http.StatusBadRequest, "invalid_request", "email or password does not meet requirements")
		return
	}
	if err != nil {
		writeError(w, http.StatusInternalServerError, "registration_failed", "account could not be created")
		return
	}
	writeJSON(w, http.StatusCreated, map[string]any{"user": publicUser(user)})
}

func (a *API) login(w http.ResponseWriter, r *http.Request) {
	var request credentialsRequest
	if err := decodeJSON(w, r, &request); err != nil {
		writeError(w, http.StatusBadRequest, "invalid_request", "provide one valid JSON email and password")
		return
	}
	pair, err := a.Auth.Login(r.Context(), request.Email, request.Password)
	if errors.Is(err, ErrInvalidCredentials) {
		writeError(w, http.StatusUnauthorized, "invalid_credentials", "email or password is incorrect")
		return
	}
	if err != nil {
		writeError(w, http.StatusInternalServerError, "login_failed", "login could not be completed")
		return
	}
	writeJSON(w, http.StatusOK, pair)
}

func (a *API) refresh(w http.ResponseWriter, r *http.Request) {
	var request refreshRequest
	if err := decodeJSON(w, r, &request); err != nil || request.RefreshToken == "" {
		writeError(w, http.StatusBadRequest, "invalid_request", "refresh_token is required")
		return
	}
	pair, err := a.Auth.Refresh(r.Context(), request.RefreshToken)
	if errors.Is(err, ErrRefreshReuse) {
		writeError(w, http.StatusUnauthorized, "refresh_reuse", "refresh token reuse detected; sign in again")
		return
	}
	if errors.Is(err, ErrRefreshInvalid) {
		writeError(w, http.StatusUnauthorized, "invalid_refresh_token", "refresh token is invalid or expired")
		return
	}
	if err != nil {
		writeError(w, http.StatusInternalServerError, "refresh_failed", "session could not be refreshed")
		return
	}
	writeJSON(w, http.StatusOK, pair)
}

func (a *API) logout(w http.ResponseWriter, r *http.Request) {
	var request refreshRequest
	if err := decodeJSON(w, r, &request); err != nil || request.RefreshToken == "" {
		writeError(w, http.StatusBadRequest, "invalid_request", "refresh_token is required")
		return
	}
	if err := a.Auth.Logout(r.Context(), request.RefreshToken); err != nil {
		writeError(w, http.StatusUnauthorized, "invalid_refresh_token", "refresh token is invalid")
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (a *API) me(w http.ResponseWriter, r *http.Request) {
	principal, _ := PrincipalFromContext(r.Context())
	user, err := a.Store.UserByID(r.Context(), principal.UserID)
	if err != nil {
		writeError(w, http.StatusUnauthorized, "unauthorized", "account is unavailable")
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"user": publicUser(user)})
}
func (a *API) adminUsers(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, http.StatusOK, map[string]string{"message": "admin access granted"})
}

func publicUser(user User) map[string]string {
	return map[string]string{"id": user.ID, "email": user.Email, "role": string(user.Role)}
}

func decodeJSON(w http.ResponseWriter, r *http.Request, destination any) error {
	r.Body = http.MaxBytesReader(w, r.Body, 16*1024)
	decoder := json.NewDecoder(r.Body)
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(destination); err != nil {
		return err
	}
	var extra any
	if err := decoder.Decode(&extra); err != io.EOF {
		return errors.New("request must contain exactly one JSON value")
	}
	return nil
}
func writeJSON(w http.ResponseWriter, status int, value any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(value)
}
func writeError(w http.ResponseWriter, status int, code, message string) {
	writeJSON(w, status, errorResponse{Error: code, Message: message})
}
